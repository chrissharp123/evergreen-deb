#!/usr/bin/perl -w
#
# Copyright (C)2010-2012 Georgia Public Library Service
# Chris Sharp <csharp@georgialibraries.org>
#
=pod

A utility to easily discover a patron's name and active card number
from the command line.  It requires the following:
1) a direct connection to the database you're trying to query
2) Perl DBI and DBD::Pg packages installed (libdbi-perl and 
   libdbd-pg-perl packages on Debian/Ubuntu)

The main use case for this is to provide a non-technical end user
(e.g., a library administrator or helpdesk manager) with a non-SQL 
way to get the active card barcode and full name of a user from an 
Evergreen user ID gathered from displayed columns in the staff client
for a circulation or hold object.

Usage:

  perl who_is.pl

=cut
use strict;
use DBI;

my $uID;
my $query;
my $db_name = "evergreen";
my $db_host = "myhost";
my $db_user = "evergreen";
my $db_pass = "mypassword";


print "Please enter the user ID: ";
chomp($uID = <STDIN>);

$query = <<END;
SELECT cd.barcode, u.first_given_name, u.second_given_name, u.family_name
	FROM actor.usr u
	JOIN actor.card cd on (cd.usr = u.id and cd.active)
	WHERE u.id = $uID;
END
#print $query; 

# connect
my $dbh = DBI->connect("DBI:Pg:dbname=$db_name;host=$db_host", "$db_user", "$db_pass", {'RaiseError' => 1});


# execute SELECT query
my $sth = $dbh->prepare("$query");
$sth->execute();
my ($cdBarcode, $first_name, $middle_name, $last_name);

# iterate through resultset
# print values
my $ref = $sth->bind_columns(\($cdBarcode, $first_name, $middle_name, $last_name));
while ($sth->fetch) {
    print "User $uID has barcode $cdBarcode and is named $first_name $middle_name $last_name.\n";
}

# clean up
$dbh->disconnect();

