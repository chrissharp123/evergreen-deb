-- config.coded value maps changes
BEGIN;
-- remove opac visibility for unused types
UPDATE config.coded_value_map SET opac_visible = FALSE WHERE ctype = 'audience' AND code IN (' ', 'a', 'b', 'c', 'd', 'f', 'g');
UPDATE config.coded_value_map SET opac_visible = FALSE WHERE ctype = 'item_form' AND code IN ('a', 'b','c', 'r', 's');
UPDATE config.coded_value_map SET opac_visible = FALSE WHERE ctype = 'item_type' AND code IN ('a', 'c', 'd', 'e', 'f', 'k', 'o', 'p', 'r', 't');
UPDATE config.coded_value_map SET opac_visible = FALSE WHERE ctype = 'lit_form' AND code IN ('0', '1', 'c', 'd', 'e', 'f', 'h', 'i', 'j', 'm', 'p', 's', 'u');
UPDATE config.coded_value_map SET opac_visible = FALSE WHERE ctype = 'vr_format' AND code IN ('a', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'm', 'o', 'p', 'q', 'u', 'z');

-- set most commonly-used languages as "simple" selectors
UPDATE config.coded_value_map SET is_simple = TRUE WHERE ctype = 'item_lang' AND code IN ('chi', 'eng', 'fre', 'ger', 'hin', 'ita', 'jpn', 'kor', 'lat', 'por', 'rus', 'spa');

-- add user-friendly search labels for certain types
UPDATE config.coded_value_map SET search_label = 'DVD/Video' WHERE ctype = 'item_type' AND code = 'g';
UPDATE config.coded_value_map SET search_label = 'Audiobooks' WHERE ctype = 'item_type' AND code = 'i';
UPDATE config.coded_value_map SET search_label = 'Music' WHERE ctype = 'item_type' AND code = 'j';

-- add new types
INSERT INTO config.coded_value_map (ctype, code, value) VALUES 'item_type', 'a,t', 'Books';
INSERT INTO config.coded_value_map (ctype, code, value) VALUES 'item_type', 'e,f', 'Maps';
INSERT INTO config.coded_value_map (ctype, code, value) VALUES 'item_type', 'o,p', 'Kits';
INSERT INTO config.coded_value_map (ctype, code, value) VALUES 'item_type', 'c,d', 'Scores/Sheet Music';
INSERT INTO config.coded_value_map (ctype, code, value) VALUES 'item_type', 'k,r', 'Other Formats';
INSERT INTO config.coded_value_map (ctype, code, value) VALUES 'lit_form', '0,c,d,e,h,i,m,p,s,u', 'Nonfiction';
INSERT INTO config.coded_value_map (ctype, code, value) VALUES 'lit_form', '1,f,j,u', 'Fiction';
INSERT INTO config.coded_value_map (ctype, code, value) VALUES 'vr_format', 'a,c,d,e,f,g,h,i,j,k,m,o,p,q,u,z', 'Other Formats';
INSERT INTO config.coded_value_map (ctype, code, value) VALUES 'item_form', 'a,b,c', 'Microform';
INSERT INTO config.coded_value_map (ctype, code, value) VALUES 'item_form', 's,q,o', 'Electronic Resources';

COMMIT;
