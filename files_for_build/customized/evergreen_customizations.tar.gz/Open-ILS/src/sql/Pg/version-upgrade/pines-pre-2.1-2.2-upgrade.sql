-- To be run before the 2.1.1-2.1.2 upgrade script

-- explicitly set the search path for the evergreen and postgres users
ALTER ROLE postgres SET search_path TO evergreen, public ;
ALTER ROLE evergreen SET search_path TO evergreen, public ;

---- clean up circulations that shouldn't be marked finished
BEGIN;
UPDATE action.circulation SET xact_finish = NULL WHERE xact_finish IS NOT NULL AND checkin_time IS NULL AND stop_fines IN ('CLAIMSRETURNED', 'MAXFINES');
COMMIT;

-- archive circs that are finished and started earlier than 1/1/2011
BEGIN;
DELETE FROM action.circulation WHERE xact_finish IS NOT NULL AND xact_start::DATE < '2011-01-01';
COMMIT;

-- delete empty volumes over 1 month old  - real    3m38.936s on test
BEGIN;
UPDATE asset.call_number acn SET deleted = TRUE WHERE NOT acn.deleted AND acn.id NOT IN (SELECT acp.call_number FROM asset.copy acp WHERE NOT acp.deleted) AND acn.create_date::DATE < '2013-02-21';
COMMIT;

-- delete empty bibs over 1 month old - real    1m23.544s on test
BEGIN;
UPDATE biblio.record_entry bre SET deleted = TRUE WHERE NOT bre.deleted and bre.id NOT IN (SELECT acn.record FROM asset.call_number acn WHERE NOT acn.deleted) AND bre.create_date::DATE < '2013-02-21';
COMMIT;

-- correct some errors causing credit forward balance (not used in PINES) to be visible and used briefly after past upgrades
-- real    2m51.435s on test
BEGIN;
UPDATE actor.usr SET credit_forward_balance = '0.00' WHERE credit_forward_balance <> '0.00';
COMMIT;

-- move some copies off of circ mods that should have been deleted on 12/31 - real    0m55.454s on test
BEGIN;
UPDATE asset.copy SET circ_modifier = 'videogame', fine_level = 1, loan_duration = 3 WHERE circ_modifier = 'videogamelong' AND NOT deleted;
UPDATE asset.copy SET circ_modifier = 'book' WHERE circ_modifier = 'atlas' AND NOT deleted;
UPDATE asset.copy SET circ_modifier = 'software', fine_level = 1, loan_duration = 3 WHERE circ_modifier = 'softwrlong' AND NOT deleted;
UPDATE asset.copy SET circ_modifier = 'equipment', fine_level = 1, loan_duration = 3 WHERE circ_modifier = 'equip-long' AND NOT deleted;
UPDATE asset.copy SET circ_modifier = 'statepass' WHERE circ_modifier = 'eventpass' AND NOT deleted;
COMMIT;

-- delete config.circ_matrix_matchpoints referring to the legacy circ mods - real    0m0.189s on test
BEGIN;
DELETE FROM config.circ_matrix_matchpoint WHERE circ_modifier IN ('videogamelong', 'atlas', 'softwrlong', 'equip-long', 'eventpass');
DELETE FROM config.hold_matrix_matchpoint WHERE circ_modifier IN ('videogamelong', 'atlas', 'softwrlong', 'equip-long', 'eventpass');
COMMIT;

-- delete those circ modifiers - real    0m49.620s
BEGIN;
DELETE FROM config.circ_modifier WHERE code IN ('videogamelong', 'atlas', 'softwrlong', 'equip-long', 'eventpass');
COMMIT;

-- create a missing schema
SELECT auditor.create_auditor ( 'serial', 'unit' );
CREATE INDEX aud_serial_unit_hist_creator_idx     ON auditor.serial_unit_history ( creator );
CREATE INDEX aud_serial_unit_hist_editor_idx      ON auditor.serial_unit_history ( editor );


-- disable triggers on biblio.record_entry and update all marc to be marked as unicode
ALTER TABLE biblio.record_entry DISABLE TRIGGER ALL;

UPDATE biblio.record_entry
    SET marc = regexp_replace(marc, E'(<leader[^>]*>.{9}).', E'\\1a');

ALTER TABLE biblio.record_entry ENABLE TRIGGER ALL;

